package elements;

public interface Element {
    public abstract void draw();
}
