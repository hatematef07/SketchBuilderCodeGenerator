import languagewrite.Attribute;
import languagewrite.Tag;
import languagewrite.WriteMarkup;

public class Runner {
    public static void main(String [] args){
        Tag html = new Tag("html");
        Tag head = new Tag("head");
        Tag title = new Tag("title");
        title.setTagValue("markup language writer test");
        head.addChild(title);

        Tag body = new Tag("body");
        Tag h1 = new Tag("h1");
        h1.setTagValue("h1 test write");
        body.addChild(h1);

        html.addChild(head);
        html.addChild(body);

        WriteMarkup writeMarkup = new WriteMarkup(html);
        writeMarkup.setDocumentDeclaration("<!DOCTYPE html>");
        writeMarkup.writeMarkupFile("test.html", WriteMarkup.MarkupFormat.HTML);

//        Tag RelativeLayout = new Tag("RelativeLayout");
//        RelativeLayout.addAttribute(new Attribute("xmlns:android", "http://schemas.android.com/apk/res/android"));
//        RelativeLayout.addAttribute(new Attribute("xmlns:tools", "http://schemas.android.com/tools"));
//        RelativeLayout.addAttribute(new Attribute("android:layout_width", "match_parent"));
//        RelativeLayout.addAttribute(new Attribute("android:layout_height", "match_parent"));
//        RelativeLayout.addAttribute(new Attribute("tools:context", "com.google.firebase.udacity.friendlychat.MainActivity"));
//
//        Tag ListView = new Tag("ListView");
//        ListView.addAttribute(new Attribute("android:id", "@+id/messageListView"));
//        ListView.addAttribute(new Attribute("android:layout_width", "match_parent"));
//        ListView.addAttribute(new Attribute("android:layout_height", "match_parent"));
//        ListView.addAttribute(new Attribute("android:layout_above", "@+id/linearLayout"));
//        ListView.addAttribute(new Attribute("android:stackFromBottom", "true"));
//        ListView.addAttribute(new Attribute("android:divider", "@android:color/transparent"));
//        ListView.addAttribute(new Attribute("android:transcriptMode", "alwaysScroll"));
//        ListView.addAttribute(new Attribute("tools:listitem", "@layout/item_message"));
//
//        RelativeLayout.addChild(ListView);
//
//        Tag LinearLayout = new Tag("LinearLayout");
//        LinearLayout.addAttribute(new Attribute("android:id", "@+id/linearLayout"));
//        LinearLayout.addAttribute(new Attribute("android:layout_width", "match_parent"));
//        LinearLayout.addAttribute(new Attribute("android:layout_height", "match_parent"));
//        LinearLayout.addAttribute(new Attribute("android:layout_alignParentBottom", "true"));
//        LinearLayout.addAttribute(new Attribute("android:layout_alignParentLeft", "true"));
//        LinearLayout.addAttribute(new Attribute("android:layout_alignParentStart", "true"));
//        LinearLayout.addAttribute(new Attribute("android:orientation", "horizontal"));
//
//        Tag ImageButton = new Tag("ImageButton");
//        ImageButton.addAttribute(new Attribute("android:id", "@+id/photoPickerButton"));
//        ImageButton.addAttribute(new Attribute("android:layout_width", "match_parent"));
//        ImageButton.addAttribute(new Attribute("android:layout_height", "match_parent"));
//        ImageButton.addAttribute(new Attribute("android:background", "@android:drawable/ic_menu_gallery"));
//
//        LinearLayout.addChild(ImageButton);
//        RelativeLayout.addChild(LinearLayout);
//
//        WriteMarkup writeMarkup = new WriteMarkup(RelativeLayout);
//        writeMarkup.setDocumentDeclaration("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
//        writeMarkup.writeMarkupFile("testxml.xml", WriteMarkup.MarkupFormat.XML);
    }
}
