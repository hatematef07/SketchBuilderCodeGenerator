package androidelements;

import elements.Element;

public abstract class AndroidElement implements Element {
    public abstract void draw();
}
